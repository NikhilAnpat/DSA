package com.demo.service;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Product;

public interface ProductService {

	void addNewProduct();

	Map<Integer, Product> displayProduct();

	Product displayById(int id);

	Set<Product> displayBynm(String nm);

	boolean deleteById(int id);

	Set<Product> sortById();

	TreeSet<Product> sortByNm();

	Set<Product> sortByCatId();
	
	

}
