package com.demo.service;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{

	private  ProductDao pd;
	
	public ProductServiceImpl(){
		super();
		this.pd=new ProductDaoImpl();
	}
	
	@Override
	public void addNewProduct() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Product id:");
		int id=sc.nextInt();
		
		System.out.println("Enter Product name:");
		String nm=sc.next();
		
		System.out.println("Enter Category id:");
		int cid=sc.nextInt();
		
		
		Product p=new Product(id,nm,cid);
		
		pd.save(p);
		
	}

	@Override
	public Map<Integer, Product> displayProduct() {
		return pd.disp();
		
	}

	@Override
	public Product displayById(int id) {
		
		return pd.dispById(id);
	}

	@Override
	public Set<Product> displayBynm(String nm) {
		
		return pd.dispBynm(nm);
	}

	@Override
	public boolean deleteById(int id) {
		
		return pd.deleteById(id);
	}

	@Override
	public Set<Product> sortById() {
		
		return pd.sortById();
	}

	@Override
	public TreeSet<Product> sortByNm() {
		return pd.sortByNm();
		
	}

	@Override
	public Set<Product> sortByCatId() {
		return pd.sortByCatId();
		
	}

}
