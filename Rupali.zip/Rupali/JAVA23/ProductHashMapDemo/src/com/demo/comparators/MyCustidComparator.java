package com.demo.comparators;

import java.util.Comparator;

import com.demo.beans.Product;

public class MyCustidComparator implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		if(o1.getCatid()<o2.getCatid())
			return -1;
		else if(o1.getCatid()==o2.getCatid())
				if(o1.getPid()<o2.getPid())
					return -1;
				else if(o1.getPid()==o2.getPid())
					return 0;
				else
					return 1;
		else
			return 1;
	}
}
