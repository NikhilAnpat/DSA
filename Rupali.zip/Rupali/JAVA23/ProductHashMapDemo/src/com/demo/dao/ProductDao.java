package com.demo.dao;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Product;

public interface ProductDao {

	void save(Product p);

	Map<Integer, Product> disp();

	Product dispById(int id);

	Set<Product> dispBynm(String nm);

	boolean deleteById(int id);

	Set<Product> sortById();

	TreeSet<Product> sortByNm();

	Set<Product> sortByCatId();



}
