package com.demo.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import com.demo.beans.Product;
import com.demo.comparators.MyCustidComparator;
import com.demo.comparators.MyNameComparator;

public class ProductDaoImpl implements ProductDao {
	private static Map<Integer,Product> emap;

	static {
				emap=new HashMap<Integer,Product>();
			
				emap.put(11,new Product(11,"Magggie",23));
				emap.put(2,new Product(2,"Magggie",23));
				emap.put(1,new Product(1,"Lays",12));
				
				emap.put(45,new Product(45,"CHips",11));
				emap.put(3,new Product(3,"Jimjam",45));
				emap.put(9,new Product(9,"Lays",5));
		}
		@Override
		public void save(Product e) {
			emap.put(e.getPid(),e);
		}
		
		@Override
		public Map<Integer,Product> disp() {
			return emap;
		}
		
		@Override
		public Product dispById(int id) {
				return  emap.get(id);
	}
		@Override
		public Set<Product> dispBynm(String nm) {
			Set<Product> ts=new HashSet<>();
			for(Integer k:emap.keySet())
			{
				if(emap.get(k).getPname().equalsIgnoreCase(nm))
				ts.add(emap.get(k));
			}
			if(emap.size()>0)
				return ts;
			return null;
			
			
		
		}
		@Override
		public boolean deleteById(int id) {
			Set<Map.Entry<Integer,Product>> pset=emap.entrySet();
			for(Map.Entry<Integer,Product> ob:pset)
			{
				if(ob.getValue().getPid()==id) {
					pset.remove(ob);
					return true;
				}
			
			}
			return false;
		}
		@Override
		public Set<Product> sortById() {
		
			Set<Product> ts=new TreeSet<>();
			for(Integer key:emap.keySet())
			{
				ts.add(emap.get(key));
			}
			return ts;
		}

		@Override
		public TreeSet<Product> sortByNm() {
			//Comparator<Product> c=(o1,o2)->{return o1.getPname().compareTo(o2.getPname());};
			TreeSet<Product> ts=new TreeSet<>(new MyNameComparator());
			for(Integer key:emap.keySet())
			{
				ts.add(emap.get(key));
			}
			return ts;
		}

		@Override
		public Set<Product> sortByCatId() {
			//Comparator<Product> c=(o1,o2)->{return o1.getCatid()(o2.getCatid());};
			TreeSet<Product> ts=new TreeSet<>(new MyCustidComparator());
			
			for(Integer key:emap.keySet())	
			{
				ts.add(emap.get(key));
			}
			return ts;
		//	return null;
		}
	}


