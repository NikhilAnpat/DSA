package com.demo.test;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

public class ProductTest {

	public static void main(String[] args) {
		int ch=0;
		ProductService ps=new ProductServiceImpl();
		
		Scanner sc=new Scanner(System.in);
		do {
			
			
				System.out.println("1. Add Product\n 2. Dispaly All\n 3. Display by Id \n 4.  Display by name\n 5. Sort by id\n 6. Sort by Category id\n 7. Delete by Id\n 8. Sort by Name\n 9.Exit");
				System.out.println("Enter Choice:");
				ch=sc.nextInt();
				
				switch(ch)
				 {
				
				case 1:
					ps.addNewProduct();
					break;
					
				case 2:
					Map<Integer,Product> hm=ps.displayProduct();
					if(hm!=null)
						System.out.println(hm);
					else
						System.out.println("Not Found....");
					break;
					
				case 3:
					System.out.println("Enter id:");
					int id=sc.nextInt();
					Product p=ps.displayById(id);
					if(p!=null)
						System.out.println(p);
					else
						System.out.println("Not Found");
					
					break;
					
				case 4:
					System.out.println("Enter name:");
					String nm=sc.next();
					 Set< Product> pset=ps.displayBynm(nm);
					if(pset!=null)
						System.out.println(pset);
					else
						System.out.println("Not Found");
					break;
					
				case 5:
					Set<Product> psort=ps.sortById();
				for(Product  ps1:psort)
						System.out.println(ps1);
					break;
					
				case 6:
					 psort=ps.sortByCatId();
					for(Product  ps1:psort)
							System.out.println(ps1);
				
					break;
					
				case 7:
					System.out.println("Enter id:");
					 id=sc.nextInt();
					boolean status=ps.deleteById(id);
					if(status)
						System.out.println("Deleted Successfully");
					else
						System.out.println("Not Found");
					
					break;
					
				case 8:
					TreeSet<Product> ns=ps.sortByNm();
						for(Product ob:ns)
								System.out.println(ob);
					break;
					
				case 9:
					sc.close();
					System.out.println("Thanks for visiting");
					
				default:
					System.out.println("Enter valid choice");
				}
		}while(ch!=9);
		
	}

}
