package com.demo.test;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class EmployeeTest {

	public static void main(String[] args) {
		int choice=0;
		EmployeeService es=new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		do {
				System.out.println("\t\t ************************ MENU *********************");
				System.out.println("\n 1. Add new Employee \n 2. DisplayAll\n 3. Display By Id\n 4. Display by Name\n 5. Sort by Id\n 6. Sort by Name\n 7. Modify Salary\n 8. Delete by Id\n 9. Sort By Salary \n 10. Exit");
				System.out.println("\n Enter Choice: ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					es.addNewEmployee();
					break;
					
				case 2:
					Map<Integer,Employee> emap=es.displayAll();
						System.out.println(emap);
					break;
					
				case 3:
					System.out.println("Enter Employee id:");
					int id=sc.nextInt();
					Employee e=es.dispalyById(id);
					if(e!=null)
						System.out.println(e);
					else
						System.out.println("not found");
					
					break;
					
				case 4:
					System.out.println("Enter Employee Name:");
					String nm=sc.next();
					Set<Employee> eset=es.dispalyByNm(nm);
					
					if(eset!=null)
						System.out.println(eset);
					else
						System.out.println("not found");
					break;
					
				case 5:
					Set<Employee> sort=new TreeSet<>();
					 sort=es.sortById();
						if(sort!=null)
							System.out.println(sort);
						else
							System.out.println("not found");
					
					break;
					
				case 6:
						sort=es.sortByNm();
						if(sort!=null)
							System.out.println(sort);
						else
							System.out.println("not found");
						break;
						
				case 7:System.out.println("Enter id to modify Salary:  ");
					id=sc.nextInt();
					System.out.println("Enter new salary:  ");
					double newsal=sc.nextDouble();
					boolean status=es.modifySal(id,newsal);
					if(status)
						System.out.println("Salary Updated successfully.........");
					else
						System.out.println("not found");
	
					break;
					
				case 8:
					System.out.println("Enter id to delete:  ");
					id=sc.nextInt();
					 status=es.deleteById(id);
					 if(status)
							System.out.println("Record deleted successfully.........");
						else
							System.out.println("not found");
					break;
						
				case 9:sort=es.sortBySal();
				if(sort!=null)
					System.out.println(sort);
				else
					System.out.println("not found");
				break;
	
					
				case 10:
					sc.close();
					break;
				}
				
			}while(choice!=10);

		}
}
