package com.demo.service;

import java.util.Map;
import java.util.Set;

import com.demo.beans.Employee;

public interface EmployeeService {

		void addNewEmployee();

		Map<Integer, Employee> displayAll();

		Employee dispalyById(int id);

		Set<Employee> dispalyByNm(String nm);

		Set<Employee> sortById();

		Set<Employee> sortByNm();

		Set<Employee> sortBySal();

		boolean modifySal(int id, double newsal);

		boolean deleteById(int id);

}
