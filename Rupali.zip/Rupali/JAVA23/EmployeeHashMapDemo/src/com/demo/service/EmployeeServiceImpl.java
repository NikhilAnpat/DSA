package com.demo.service;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Employee;
import com.demo.dao.EmployeeDao;
import com.demo.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao ed;
	
	

	public EmployeeServiceImpl() {
		super();
		ed=new EmployeeDaoImpl();
	}



	@Override
	public void addNewEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee id:");
		int eid=sc.nextInt();
		
		System.out.println("Enter Employee name:");
		String ename=sc.next();
		
		System.out.println("Enter Employee Salary:");
		double esal=sc.nextDouble();
		
		System.out.println("Enter Employee email:");
		String email=sc.next();
		
		Employee e=new Employee(eid,ename,esal,email);
		ed.save(e);
		
		
		
		
	}



	@Override
	public Map<Integer, Employee> displayAll() {
		
		return ed.displayAll();
	}



	@Override
	public Employee dispalyById(int id) {
		
		return ed.displayById(id);
	}



	@Override
	public Set<Employee> dispalyByNm(String nm) {
		
		return ed.dispByName(nm);
	}



	@Override
	public Set<Employee> sortById() {
		
		return ed.sortById();
	}



	@Override
	public Set<Employee> sortByNm() {
		
		return ed.sortBynm();
	}



	@Override
	public Set<Employee> sortBySal() {
		
		return ed.sortBySal();
	}



	@Override
	public boolean modifySal(int id, double newsal) {
		
		return ed.modifySal(id,newsal);
	}



	@Override
	public boolean deleteById(int id) {
		
		return ed.deletebyId(id);
	}

}
