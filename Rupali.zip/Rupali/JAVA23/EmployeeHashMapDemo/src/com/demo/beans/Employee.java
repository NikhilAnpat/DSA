package com.demo.beans;

import java.util.Comparator;

public class Employee implements Comparable<Employee>{
	
	private int empid;
	private String ename;
	private double esal;
	private String emailid;
	
	public Employee() {
		super();
	}
	
	public Employee(int empid, String ename, double esal, String emailid) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.esal = esal;
		this.emailid = emailid;
	}
	
	public Employee(int id) {
		this.empid = id;
		this.ename = null;
		this.esal = 0;
		this.emailid = null;
	}

	public int getEmpid() {
		return empid;
	}
	
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	
	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public double getEsal() {
		return esal;
	}
	
	public void setEsal(double esal) {
		this.esal = esal;
	}
	
	public String getEmailid() {
		return emailid;
	}
	
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", esal=" + esal + ", emailid=" + emailid + "]";
	}

	@Override
	public int hashCode() {
		
		return empid;
	}

	@Override
	public boolean equals(Object obj) {
		
		return empid==((Employee)obj).empid;
	}

	@Override
	public int compareTo(Employee o) {
		
		return this.empid-o.empid;
	}
	
	
	

}
