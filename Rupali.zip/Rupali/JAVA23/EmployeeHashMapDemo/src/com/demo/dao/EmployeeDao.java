package com.demo.dao;

import java.util.Map;
import java.util.Set;

import com.demo.beans.Employee;

public interface EmployeeDao {

	void save(Employee e);

	Map<Integer, Employee> displayAll();

	Employee displayById(int id);

	Set<Employee> dispByName(String nm);

	Set<Employee> sortById();

	Set<Employee> sortBynm();

	Set<Employee> sortBySal();

	boolean deletebyId(int id);

	boolean modifySal(int id, double newsal);

}
