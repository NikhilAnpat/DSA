package com.demo.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
		private static Map<Integer,Employee> hm;
		static {
			hm=new HashMap<Integer,Employee>();
			hm.put(3, new Employee(3,"Roshani",95000,"rosh@gmail.com"));
			hm.put(1, new Employee(1,"Shailesh",56000,"shailu@gmail.com"));
			hm.put(2, new Employee(2,"Shrey",67000,"shrey@gmail.com"));
		}
	
	
	@Override
	public void save(Employee e) {
		hm.put(e.getEmpid(),e);
		
	}


	@Override
	public Map<Integer, Employee> displayAll() {
		return hm;
	}


	@Override
	public Employee displayById(int id) {
	
		return hm.get(id);
	}


	@Override
	public Set<Employee> dispByName(String nm) {
		Set<Employee> eset=new HashSet<>();
		for(Integer key:hm.keySet())
		{
			if(hm.get(key).getEname().equals(nm))
			{
				eset.add(hm.get(key));
			}
		}
		return eset;
	}


	@Override
	public Set<Employee> sortById() {
		Set<Employee> eset=new TreeSet<>();
		for(Integer key:hm.keySet())
		{
			eset.add(hm.get(key));
			//System.out.println(hm.get(key));
		}
		
		return eset;
	}


	@Override
	public Set<Employee> sortBynm() {
		
		Comparator<Employee> c=(o1,o2)->{return o1.getEname().compareTo(o2.getEname());};
		Set<Employee> newset=new TreeSet<>(c);
		for(Integer key:hm.keySet())
		{
			newset.add(hm.get(key));
			
		}
		return newset;
	}


	@Override
	public Set<Employee> sortBySal() {
		Comparator<Employee> c=(o1,o2)->{return (int) (o1.getEsal()-(o2.getEsal()));};
		Set<Employee> newset=new TreeSet<>(c);
		for(Integer key:hm.keySet())
		{
			newset.add(hm.get(key));
			
		}
		return newset;
	}


	@Override
	public boolean deletebyId(int id) {
		if(hm.remove(id)!=null)
		return true;
		else
			return false;
	
	}


	@Override
	public boolean modifySal(int id, double newsal) {
		hm.get(id).setEsal(newsal);
		return true;
	}
	

}
