package com.demo.service;

public interface StudentService {

	void writeFile();

	void readFile();
    
}
