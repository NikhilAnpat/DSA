package com.demo.service;

public class MyServiceImpl implements MyService{

}
