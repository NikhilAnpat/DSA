package InterfaceDemo;

public class MyClass implements I1 {

	@Override
	public void add(int x, int y) {
		System.out.println("Myclass Addition = "+(x+y));
		
	}

	@Override
	public void mul(int x, int y) {
		System.out.println("Myclass Multiplication = "+(x*y));
		
	}

	
	public void add1()
	{
		System.out.println("Myclass Addition = "+(200+10));
	}
	
	
	
//	public static void sub()
//	{
//		System.out.println("Sutraction = "+(240-10));
//	}
}
