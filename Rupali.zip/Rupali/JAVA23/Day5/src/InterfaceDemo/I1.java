package InterfaceDemo;

public interface I1 {
	void add(int x,int y);
	void mul(int x,int y);
	
	public static void sub()
	{
		System.out.println("Sutraction = "+(20-10));
	}
	
	default void add1()
	{
		System.out.println("Default Addition = "+(20+10));
	}
} 
