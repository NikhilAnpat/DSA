package InterfaceDemo;

public class TestInterface {

	public static void main(String[] args) {
		I1 ob=new MyClass();
		ob.add(23, 67);
		ob.mul(5,10);
		ob.add1();
		I1.sub();

	}

}
