package FunctionalInterfaceDemo;

public class MyClass1   {

	public static void main(String[] args) {
		
		FunctionalInterface<String> ob=(x,y)->{return x.length()>y.length()?x:y;};
		System.out.println(ob.compare("Helloww", "Hello"));
		
		FunctionalInterface<Integer> ob1=(x,y)->{return x>y?x+y:y;};
		System.out.println(ob1.compare(55, 33));
		
//		FunctionalInterface<Integer,Long> ob1=(x,y)->{return x>y?x:y;};
//		System.out.println(ob1.compare(5555, 55555));

	}
}

