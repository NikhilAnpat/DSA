package FunctionalInterfaceDemo;

public interface FunctionalInterface<T> {
	 T compare(T x,T y);

}
