package Student;

public class StudentTester {

	public static void main(String[] args) {
		
		StudentService.getInfo();
		StudentService.display();

	}

}
