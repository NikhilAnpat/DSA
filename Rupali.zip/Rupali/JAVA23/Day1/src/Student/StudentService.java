package Student;
import java.util.Scanner;

public class StudentService {
	
	static Student[] ss;
	static int cnt;
	static {
		ss=new Student[2];
		cnt=0;
		
	}
	//static StudentService[] ss=new StudentService[2];

	public static  void getInfo() {
		
		Scanner s=new Scanner(System.in);
		
		for(int i=0;i<ss.length;i++)
		{
			System.out.println("Enter Student Id: ");
			int sid=s.nextInt();
			
			System.out.println("Enter Student name: ");
			String sname=s.next();
			
			System.out.println("Enter m1: ");
			int m1=s.nextInt();
			
			System.out.println("Enterm2: ");
			int m2=s.nextInt();
			
			System.out.println("Enter m3: ");
			int m3=s.nextInt();
			
			
			
			 ss[i]=new Student(sid,sname,m1,m2,m3);
		}
		
		
		
	
		
		
	}

	public static void display() {
		
		for(int i=0;i<ss.length;i++)
		{
			System.out.println("Student Details:\n");
			System.out.println("_____________________");
			
			System.out.println("Student Id : "+ss[i].getStudId());
			System.out.println("Student name : "+ss[i].getName());
			
			System.out.println("M1 : "+ss[i].getM1());
			System.out.println("M2 : "+ss[i].getM2());
			System.out.println("m3 : "+ss[i].getM3());
			
			
		}
		
	}

}
