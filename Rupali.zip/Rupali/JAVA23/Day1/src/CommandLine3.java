//Accept 3 numbers from command line arguments. If number is prime, then print the table of
//the number. Other wise divide number by 10 and display output

public class CommandLine3 {

	public static void main(String[] args) {
		int no=0;
		for(int i=0;i<args.length;i++)
		{ 
			int d=2;
			no=Integer.parseInt(args[i]);
			while(d<=no/2)
			{
				if(no%d==0)
				{
					System.out.println(no+" is not prime so " +no/10);
					break;
				}
				else
				{
					for(int j=1;j<=10;j++)
					{
						System.out.println(no+" * "+j+" = "+(no*j));
					}
					
				}
				break;
				
			}
			d++;
			
		}

	}

}
