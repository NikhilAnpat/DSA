package com.demo.service;


import java.util.Set;

import com.demo.beans.Employee;

public interface EmployeeService {
		
		void addNewEmployee();

		Set<Employee> displayAll();

		Employee displayById(int id);

	Set<Employee> displayByName(String nm);

		Set<Employee> sortBySalary();

		Set<Employee> sortByName();

		boolean modifySalary(int id, long sal);

		boolean deleteById(int id);

		Set<Employee> sortByDesig();

}
