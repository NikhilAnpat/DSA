package com.demo.dao;

import java.util.Set;

import com.demo.beans.Employee;

public interface EmployeeDao {

	void save(Employee e);

	

	Set<Employee> getAllEmployees();

	Employee dispalyInFoById(int id);

	

	Set<Employee> dispalyInFoByName(String nm);

	Set<Employee> sortBySal();

	Set<Employee> sortByNm();


	boolean modifySal(int id, long sal);

	boolean deleteInfoById(int id);



	Set<Employee> sortByDesignation();


}
