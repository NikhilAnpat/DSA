package com.demo.dao;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.demo.beans.Employee;
import com.demo.comparator.MyDesignationComparator;
import com.demo.comparator.MyNameComparator;

public class EmployeeDaoImpl implements EmployeeDao {
	private static Set<Employee> hset;
	
	static {
		hset=new HashSet<Employee>();
		hset.add(new Employee(11,"Roshani","manager",978000));
		hset.add(new Employee(2,"Roshani","manager",90000));
	}
	
	
	@Override
	public void save(Employee e) {
		hset.add(e);
		
	}
	@Override
	public Set<Employee> getAllEmployees() {
		for(Employee e:hset)
		{
			System.out.println(e);
		}
	return null;
}

	

	@Override
	public Employee dispalyInFoById(int id) {
		for(Employee e:hset)
		{
			if(e.getEmpid()==id)
			return e;
		}
	return null;
			
	}

	@Override
	public Set<Employee> dispalyInFoByName(String nm) {
		
		Set<Employee> hnewset=new HashSet<Employee>();
		for(Employee e:hset)
		{
			if(e.getName().equals(nm))
				hnewset.add(e);
		}
		
		if(hset.size()>0)
			return hnewset;
		
	return null;
			
	}
	@Override
	public Set<Employee> sortBySal() {
		Set<Employee> newset=new TreeSet<>();
		for(Employee e:hset) {
			newset.add(e);
			
		}
		return newset;
		
		
		
		
	}
	@Override
	public Set<Employee> sortByNm() {
		
		Comparator<Employee> c=(o1,o2)->{return o1.getName().compareTo(o2.getName());};
		Set<Employee> newlist=new TreeSet<>(c);
		for(Employee e:hset)
			newlist.add(e);
		
		return newlist;
	}
	@Override
	public boolean modifySal(int id, long sal) {
		Employee e=dispalyInFoById(id);
		e.setSalary(sal);
		return true;
		
		
	}

	@Override
	public boolean deleteInfoById(int id) {
		Employee e=dispalyInFoById(id);
		hset.remove(e);
		return true;
		
	}
	@Override
	public Set<Employee> sortByDesignation() {
		
		Comparator<Employee> c=(o1,o2)->{return o1.getDesg().compareTo(o2.getDesg());};
		Set<Employee> newlist=new TreeSet<>(c);
		for(Employee e:hset)
			newlist.add(e);
		
		return newlist;
	}

}
