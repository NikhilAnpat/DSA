package InheritancePersonDemo;

public class PHDStudent extends Student{

	private int spsub;
	private String thesis;
	
	public PHDStudent() {
		super();
	}

	public PHDStudent(int id,String nm,int mobile,int m1,int m2,int m3,int spsub, String thesis) {
		super(id,nm,mobile,m1,m2,m3);
		this.spsub = spsub;
		this.thesis = thesis;
	}

	public int getSpsub() {
		return spsub;
	}

	public void setSpsub(int spsub) {
		this.spsub = spsub;
	}

	public String getThesis() {
		return thesis;
	}

	public void setThesis(String thesis) {
		this.thesis = thesis;
	}

	
	@Override
	public String toString() {
		return super.toString()+" PHDStudent [spsub=" + spsub + ", thesis=" + thesis + "]";
	}

	@Override
	public float calcPercentage() {
		return (getM1()+getM2()+getM3()+spsub)/4;
		
		
	}
	
	
}
