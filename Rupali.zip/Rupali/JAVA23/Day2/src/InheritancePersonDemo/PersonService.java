package InheritancePersonDemo;

import java.util.Scanner;

public class PersonService {

	private static int cnt;
	private static Person parr[];
	
	static
	{
		cnt=0;
		parr=new Person[20];
	}
	
	public static void addNew(int choice) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		

		System.out.println("Enter name:");
		String nm=sc.next();
		

		System.out.println("Enter mobile:");
		int mobile=sc.nextInt();
		
		if(choice<3)
		{
			System.out.println("Enter m1:");
			int m1=sc.nextInt();
			

			System.out.println("Enter m2:");
			int m2=sc.nextInt();
			
			System.out.println("Enter m3:");
			int m3=sc.nextInt();
			
			if(choice==1)
			{
				System.out.println("Enter special subject Marks:");
				int sp=sc.nextInt();
				

				System.out.println("Enter thesis:");
				String t=sc.next();
				
				parr[cnt]=new PHDStudent(id,nm,mobile,m1,m2,m3,sp,t);
			}
			else
			{
				System.out.println("Enter m4:");
				int m4=sc.nextInt();
				

				System.out.println("Enter m5:");
				int m5=sc.nextInt();
				
				System.out.println("Enter special course marks:");
				int spn=sc.nextInt();
				
				parr[cnt]=new MasterStudent(id,nm,mobile,m1,m2,m3,m4,m5,spn);
			}
		}
		else
		{

			System.out.println("Enter Skill:");
			String skill=sc.next();
			

			System.out.println("Enter dept:");
			String dept=sc.next();
			
			parr[cnt]=new Faculty(id,nm,mobile,skill,dept);
		}
		
		cnt++;
	}

	public static void displayAll() {
		for(int i=0;i<cnt;i++)
		{
			System.out.println(parr[i]);
		}
		
	}

	public static Student serachById(int id)
	{
		for(int i=0;i<cnt;i++)
		{
			if(id==parr[i].getId())
				if(parr[i] instanceof Student)
					return (Student)parr[i];
				else
					return null;
			
		}

		return null;
		
		
	}

	public static float calculatePercentage(int id) {
		Student s=serachById(id);
		if(s!=null)
			return s.calcPercentage();
		else
		return -1;
		
	}

	public static void findGrade(int id1) {
		float res=0;
		Student s=serachById(id1);
		if(s!=null)
			res=s.calcPercentage();
		
		if(res>=75)
			System.out.println("\n Grade A");
		
		else if(res<75 && res>=65)
			System.out.println("\n Grade B");
		
		else if(res<65 && res>55)
			System.out.println("\n Grade c");
		
		else
			System.out.println("\n Fail.....");
		
		
		
		
		
	}

	public static String totalStaff() {
		int pcnt=0,mcnt=0,fcnt=0;
		for(int i=0;i<cnt;i++)
		{
			if(parr[i] instanceof PHDStudent)
					pcnt++;
		
			
			else if(parr[i] instanceof MasterStudent)
				mcnt++;
			
			else
				fcnt++;
			
			return "PHD Student count= "+pcnt+"\n Master Student Count= "+mcnt+ "\n Faculty Count= "+fcnt;
		}
		
		return null;
		
	}
	
}
