package InheritancePersonDemo;

public class MasterStudent extends Student{

		private int m4,m5,spcourse;

		public MasterStudent() {
			super();
		}

		public MasterStudent(int id,String nm,int mobile,int m1,int m2,int m3,int m4, int m5, int spcourse) {
			super(id,nm,mobile,m1,m2,m3);
			this.m4 = m4;
			this.m5 = m5;
			this.spcourse = spcourse;
		}

		public int getM4() {
			return m4;
		}

		public void setM4(int m4) {
			this.m4 = m4;
		}

		public int getM5() {
			return m5;
		}

		public void setM5(int m5) {
			this.m5 = m5;
		}

		public int getSpcourse() {
			return spcourse;
		}

		public void setSpcourse(int spcourse) {
			this.spcourse = spcourse;
		}

		@Override
		public String toString() {
			return super.toString()+" MasterStudent [m4=" + m4 + ", m5=" + m5 + ", spcourse=" + spcourse + "]";
		}

		@Override
		public float calcPercentage() {
			
			return (getM1()+getM2()+getM3()+spcourse+m4+m5)/6;
		}
		
		
}
