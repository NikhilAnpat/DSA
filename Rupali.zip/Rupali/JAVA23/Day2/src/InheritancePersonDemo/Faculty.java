package InheritancePersonDemo;

public class Faculty extends Person {
	private String skill,dept;

	public Faculty() {
		super();
	}

	public Faculty(int id,String nm,int mobile,String skill, String dept) {
		super(id,nm,mobile);
		this.skill = skill;
		this.dept = dept;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return super.toString()+" Faculty [skill=" + skill + ", dept=" + dept + "]";
	}
	
	
}
