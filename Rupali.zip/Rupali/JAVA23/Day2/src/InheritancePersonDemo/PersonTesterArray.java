package InheritancePersonDemo;

import java.util.Scanner;

public class PersonTesterArray {

	public static void main(String[] args) {
		int ch;
		Scanner sc=new Scanner(System.in);
	
		do{
			System.out.println("1. Add new\n 2. DisplayAll \n 3. calculate Percentage\n 4. Find Grades\n 5. Exit..");
			System.out.println("Enter Choice: ");
			 ch=sc.nextInt();
			 
			 switch(ch)
			 {
			 case 1:
				 System.out.println("1. PHD Student \n 2. Master Student \n 3. Faculty \n" );
				 System.out.println("Enter Choice: ");
				 int choice=sc.nextInt();
				 PersonService.addNew(choice);
				 break;
				 
			 case 2:
				 PersonService.displayAll();
				 break;
				 
			 case 3:
				 System.out.println("Enter id to find Percentage: ");
				 int id=sc.nextInt();
				float per= PersonService.calculatePercentage(id);
				System.out.println("Percentage for student id "+id+" is "+per);
				 break;
				 
			 case 4:
				 System.out.println("Enter id to find grade: ");
				 int id1=sc.nextInt();
				 PersonService.findGrade(id1);
				 break;
				 
			 case 5:
				 sc.close();
				 System.out.println("Thanks for visiting.....");
				 break;
			 }
			
		}while(ch!=5);
		
		String count=PersonService.totalStaff();
			System.out.println(count);

	}

}
