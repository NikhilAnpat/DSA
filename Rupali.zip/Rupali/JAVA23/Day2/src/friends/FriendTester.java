package friends;

import java.util.Date;

public class FriendTester {

	public static void main(String[] args) {
		
		//Date d=new Date();
		Friends f1=new Friends(1,"roshani","bhad@gmail.com","566565",new Date(),"chinchwad");
		System.out.println(f1);
		
//		Friends f=new Friends();
//		System.out.println(f);
	}

}
