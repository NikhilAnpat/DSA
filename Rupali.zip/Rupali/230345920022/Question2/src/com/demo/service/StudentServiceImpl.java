package com.demo.service;

import java.util.Map;
import java.util.Scanner;

import com.demo.beans.Student;
import com.demo.dao.StudentDao;
import com.demo.dao.StudentDaoImpl;

public class StudentServiceImpl implements  StudentService{
	
	private StudentDao sdao;
	Student sarr[];

	public StudentServiceImpl() {
		super();
		this.sdao = new StudentDaoImpl();
		sarr=new Student[5];
	}
	
	public void addData() {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<sarr.length;i++) {
	
		System.out.println("enter Rollno:");
		int roll=sc.nextInt();
		
		System.out.println("Enter name:");
		String name=sc.next();
		
		sarr[i]=new Student(roll,name);
		sdao.adddata(sarr[i]);
		}
		
	}

	@Override
	public Map<Integer, Student> showAllRollNumbers() {
		
	
		return sdao.showByRoll();
	}

	@Override
	public Map<Integer, Student> showAllNames() {
	
		return sdao.showByNames();
	}

}
