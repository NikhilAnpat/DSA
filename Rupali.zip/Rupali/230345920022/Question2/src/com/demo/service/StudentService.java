package com.demo.service;

import java.util.Map;

import com.demo.beans.Student;

public interface StudentService {

	Map<Integer, Student> showAllRollNumbers();

	Map<Integer, Student> showAllNames();

	void addData();

}
