package com.demo.dao;

import java.util.Map;

import com.demo.beans.Student;

public interface StudentDao {

	Map<Integer, Student> showByRoll();

	Map<Integer, Student> showByNames();

	void adddata(Student student);

}
