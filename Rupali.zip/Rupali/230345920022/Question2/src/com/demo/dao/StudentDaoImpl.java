package com.demo.dao;

import java.util.HashMap;
import java.util.Map;

import com.demo.beans.Student;

public class StudentDaoImpl implements StudentDao{

	private static Map<Integer,Student> map1;
	static{
		map1=new HashMap<Integer,Student>();
		
	}
	
	@Override
	public Map<Integer, Student> showByRoll() {
		
		return map1;
	}

	@Override
	public Map<Integer, Student> showByNames() {
		
		return map1;
	}

	@Override
	public void adddata(Student s) {
		
		map1.put(s.getRollnumber(),s);
	}

}
