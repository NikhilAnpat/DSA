package com.demo.test;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Student;
import com.demo.service.StudentService;
import com.demo.service.StudentServiceImpl;

public class HashMapDemo {
	
	public static void main(String ar[]) {
		int ch=0;
		
		StudentService ss=new StudentServiceImpl();
		Scanner sc=new Scanner(System.in);
	
	
		do {
			System.out.println("1. AddData\n 2. Show all rollnumbers in hashmap\n 3. Show all names in HashMap\n 4. Exit");
			System.out.println("Enter choice:");
			ch=sc.nextInt();
			  switch(ch) {
			  
			  case 1:
				  ss.addData();
				  break;
				  
			 case 2:
					Map<Integer, Student> map1=ss.showAllRollNumbers();
					
					Set<Integer> s=map1.keySet();
					Iterator<Integer> it=((Set<Integer>) map1).iterator();
					while(it.hasNext()) {
						Integer d=it.next();
						System.out.println(d);
				}
	
				 break;
				 
			 case 3:
				map1= ss.showAllNames();
				 Set<Integer> s1=map1.keySet();
				 break;
				 
			 case 4:
				 System.out.println("Thank You");
				 sc.close();
				 
				 default:
					 System.out.println("Entered invalid choice:");
			 }
		}while(ch!=3);
		
		
	
	
	}

}
